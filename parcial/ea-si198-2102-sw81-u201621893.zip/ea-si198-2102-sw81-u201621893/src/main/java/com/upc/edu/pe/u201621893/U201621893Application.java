package com.upc.edu.pe.u201621893;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class U201621893Application {

    public static void main(String[] args) {
        SpringApplication.run(U201621893Application.class, args);
    }

}
