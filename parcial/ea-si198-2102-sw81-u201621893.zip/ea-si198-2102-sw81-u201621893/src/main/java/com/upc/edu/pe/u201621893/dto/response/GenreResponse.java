package com.upc.edu.pe.u201621893.dto.response;


import lombok.Data;


@Data
public class GenreResponse {

    private Long id;

    private String name;

    private String description;
}
