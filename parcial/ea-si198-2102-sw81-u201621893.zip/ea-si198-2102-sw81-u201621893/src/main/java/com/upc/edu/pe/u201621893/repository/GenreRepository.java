package com.upc.edu.pe.u201621893.repository;


import com.upc.edu.pe.u201621893.model.Genre;

public interface GenreRepository extends GenericRepository<Genre,Long> {
}
