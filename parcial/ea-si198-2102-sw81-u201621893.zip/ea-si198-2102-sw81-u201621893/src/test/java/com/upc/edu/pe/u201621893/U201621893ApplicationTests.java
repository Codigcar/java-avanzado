package com.upc.edu.pe.u201621893;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class U201621893ApplicationTests {

    @Test
    void contextLoads() {
    }

}
